# Mug Music

By Bonnie Eisenman and Harvest Zhang

## How to Use

A full Instructable can be found at (link tbd).

## Credits

Code adapted from:
- madlabdk's touche_peak file is reproduced here without significant modifications: https://github.com/madlabdk/touche
- Mostly based on instrcutions here: www.instructables.com/id/Touche-for-Arduino-Advanced-touch-sensing/?ALLSTEPS
- Original Touché paper: http://www.disneyresearch.com/wp-content/uploads/touchechi2012.pdf
- ChucK is a project from our school, Princeton University

Sound files are from [Mike Koenig](http://koenigmediallc.com/mike-koenig-nc.php), liscensed under Creative Commons 3.0. We adapted them here.

